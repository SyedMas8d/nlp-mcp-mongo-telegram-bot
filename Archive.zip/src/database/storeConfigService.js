const dbConnection = require("./connection");
const logger = require("../utils/logger");

class StoreConfigService {
  constructor() {
    this.collectionName = process.env.COLLECTION_NAME || "storeconfigs";
  }

  async getCollection() {
    const db = await dbConnection.connect();
    return db.collection(this.collectionName);
  }

  /**
   * Get store configuration by store ID
   */
  async getStoreConfig(storeId) {
    try {
      const collection = await this.getCollection();
      const config = await collection.findOne({ storeId: storeId.toString() });

      if (!config) {
        logger.warn(`Store config not found for storeId: ${storeId}`);
        return null;
      }

      return config;
    } catch (error) {
      logger.error(`Error getting store config for ${storeId}:`, error);
      throw error;
    }
  }

  /**
   * Update specific fields in the current configuration
   */
  async updateCurrentConfig(storeId, updateFields) {
    try {
      const collection = await this.getCollection();

      // Build update object with current. prefix
      const updateObj = {};
      Object.keys(updateFields).forEach((key) => {
        updateObj[`current.${key}`] = updateFields[key];
      });
      updateObj.updatedAt = new Date();

      const result = await collection.updateOne(
        { storeId: storeId.toString() },
        { $set: updateObj }
      );

      if (result.matchedCount === 0) {
        throw new Error(`Store not found with ID: ${storeId}`);
      }

      logger.info(`Updated store config for ${storeId}:`, updateFields);
      return result;
    } catch (error) {
      logger.error(`Error updating store config for ${storeId}:`, error);
      throw error;
    }
  }

  /**
   * Revert to default settings
   */
  async revertToDefault(storeId, specificField = null) {
    try {
      const collection = await this.getCollection();
      const doc = await collection.findOne({ storeId: storeId.toString() });

      if (!doc) {
        throw new Error(`Store not found with ID: ${storeId}`);
      }

      const updateObj = { updatedAt: new Date() };

      if (specificField) {
        // Revert specific field only
        if (!doc.default.hasOwnProperty(specificField)) {
          throw new Error(
            `Field '${specificField}' not found in default configuration`
          );
        }
        updateObj[`current.${specificField}`] = doc.default[specificField];
        logger.info(
          `Reverted field '${specificField}' to default for store ${storeId}`
        );
      } else {
        // Revert all settings
        updateObj.current = { ...doc.default };
        logger.info(`Reverted all settings to default for store ${storeId}`);
      }

      const result = await collection.updateOne(
        { storeId: storeId.toString() },
        { $set: updateObj }
      );

      return result;
    } catch (error) {
      logger.error(`Error reverting to default for ${storeId}:`, error);
      throw error;
    }
  }

  /**
   * Create a new store configuration
   */
  async createStoreConfig(storeConfig) {
    try {
      const collection = await this.getCollection();

      const newConfig = {
        ...storeConfig,
        storeId: storeConfig.storeId.toString(),
        createdAt: new Date(),
        updatedAt: new Date(),
        __v: 0,
      };

      const result = await collection.insertOne(newConfig);
      logger.info(`Created new store config for ${storeConfig.storeId}`);
      return result;
    } catch (error) {
      logger.error(`Error creating store config:`, error);
      throw error;
    }
  }

  /**
   * Delete store configuration
   */
  async deleteStoreConfig(storeId) {
    try {
      const collection = await this.getCollection();
      const result = await collection.deleteOne({
        storeId: storeId.toString(),
      });

      if (result.deletedCount === 0) {
        throw new Error(`Store not found with ID: ${storeId}`);
      }

      logger.info(`Deleted store config for ${storeId}`);
      return result;
    } catch (error) {
      logger.error(`Error deleting store config for ${storeId}:`, error);
      throw error;
    }
  }

  /**
   * Get all stores that are temporarily closed and should be reopened
   */
  async getExpiredClosedStores() {
    try {
      const collection = await this.getCollection();
      const now = Date.now();

      const expiredStores = await collection
        .find({
          "current.tempClosed": true,
          "current.tempClosedTill": { $lte: now },
        })
        .toArray();

      return expiredStores;
    } catch (error) {
      logger.error("Error getting expired closed stores:", error);
      throw error;
    }
  }

  /**
   * Get all store configurations (for admin purposes)
   */
  async getAllStoreConfigs(limit = 50, skip = 0) {
    try {
      const collection = await this.getCollection();
      const configs = await collection
        .find({})
        .skip(skip)
        .limit(limit)
        .sort({ updatedAt: -1 })
        .toArray();

      return configs;
    } catch (error) {
      logger.error("Error getting all store configs:", error);
      throw error;
    }
  }
}

module.exports = new StoreConfigService();
