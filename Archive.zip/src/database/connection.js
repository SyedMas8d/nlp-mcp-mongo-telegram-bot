const { MongoClient } = require("mongodb");
const logger = require("../utils/logger");

class DatabaseConnection {
  constructor() {
    this.client = null;
    this.db = null;
    this.isConnected = false;
  }

  async connect() {
    try {
      if (this.isConnected) {
        return this.db;
      }

      const uri = process.env.MONGODB_URI;
      const dbName = process.env.MONGODB_DATABASE || "test";

      if (!uri) {
        throw new Error("MONGODB_URI environment variable is not set");
      }

      this.client = new MongoClient(uri, {
        maxPoolSize: 10,
        serverSelectionTimeoutMS: 5000,
        socketTimeoutMS: 45000,
      });

      await this.client.connect();
      this.db = this.client.db(dbName);
      this.isConnected = true;

      logger.info(`Connected to MongoDB database: ${dbName}`);
      return this.db;
    } catch (error) {
      logger.error("Failed to connect to MongoDB:", error);
      throw error;
    }
  }

  async disconnect() {
    try {
      if (this.client) {
        await this.client.close();
        this.isConnected = false;
        logger.info("Disconnected from MongoDB");
      }
    } catch (error) {
      logger.error("Error disconnecting from MongoDB:", error);
    }
  }

  getDb() {
    if (!this.isConnected || !this.db) {
      throw new Error("Database not connected. Call connect() first.");
    }
    return this.db;
  }

  async ping() {
    try {
      await this.db.admin().ping();
      return true;
    } catch (error) {
      logger.error("Database ping failed:", error);
      return false;
    }
  }
}

// Create singleton instance
const dbConnection = new DatabaseConnection();

module.exports = dbConnection;
