const storeConfigService = require("../database/storeConfigService");
const logger = require("../utils/logger");

class MCPToolExecutor {
  /**
   * Execute MCP tool based on intent and parameters
   */
  async executeTool(intent, parameters, storeId) {
    try {
      switch (intent) {
        case "CLOSE_STORE":
          return await this.closeStoreTemporarily(storeId, parameters);

        case "UPDATE_MINIMUM_ORDER":
          return await this.updateMinimumOrder(storeId, parameters);

        case "UPDATE_STORE_HOURS":
          return await this.updateStoreHours(storeId, parameters);

        case "TOGGLE_SERVICE":
          return await this.toggleServiceFeature(storeId, parameters);

        case "GET_STATUS":
          return await this.getStoreStatus(storeId);

        case "REOPEN_STORE":
          return await this.reopenStore(storeId);

        case "REVERT_TO_DEFAULT":
          return await this.revertToDefault(storeId, parameters);

        case "UPDATE_WELCOME_MESSAGE":
          return await this.updateWelcomeMessage(storeId, parameters);

        case "UPDATE_GIFT_CARD":
          return await this.updateGiftCardConfig(storeId, parameters);

        case "UPDATE_LOYALTY_POINTS":
          return await this.updateLoyaltyPoints(storeId, parameters);

        case "HELP":
          return this.getHelpMessage();

        default:
          throw new Error(`Unknown intent: ${intent}`);
      }
    } catch (error) {
      logger.error(`Error executing tool for intent ${intent}:`, error);
      throw error;
    }
  }

  /**
   * Tool: Close store temporarily
   */
  async closeStoreTemporarily(storeId, { durationMinutes, reason }) {
    const currentTime = Date.now();
    const reopenTime = currentTime + durationMinutes * 60 * 1000;

    const updateFields = {
      tempClosed: true,
      tempClosedTill: reopenTime,
      tempCloseMessage: reason || "Temporarily closed",
    };

    await storeConfigService.updateCurrentConfig(storeId, updateFields);

    const reopenTimeStr = new Date(reopenTime).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });

    return {
      success: true,
      message: `✅ Store temporarily closed for ${durationMinutes} minutes. Will automatically reopen at ${reopenTimeStr}.`,
      data: {
        closedUntil: reopenTime,
        duration: durationMinutes,
        reason: reason || "Temporarily closed",
      },
    };
  }

  /**
   * Tool: Update minimum order value
   */
  async updateMinimumOrder(storeId, { minimumAmount }) {
    const updateFields = {
      minimumOrderForDelivery: minimumAmount,
    };

    await storeConfigService.updateCurrentConfig(storeId, updateFields);

    return {
      success: true,
      message: `✅ Minimum delivery order updated to $${minimumAmount}.`,
      data: {
        minimumOrderForDelivery: minimumAmount,
      },
    };
  }

  /**
   * Tool: Update store hours
   */
  async updateStoreHours(storeId, { openTime, closeTime }) {
    const updateFields = {};

    if (openTime) updateFields.openTime = openTime;
    if (closeTime) updateFields.closeTime = closeTime;

    await storeConfigService.updateCurrentConfig(storeId, updateFields);

    let message = "✅ Store hours updated:";
    if (openTime) message += ` Opens at ${openTime}`;
    if (closeTime) message += ` Closes at ${closeTime}`;

    return {
      success: true,
      message,
      data: updateFields,
    };
  }

  /**
   * Tool: Toggle service feature
   */
  async toggleServiceFeature(storeId, { feature, enabled }) {
    const fieldMap = {
      collection: "enableCollectionOrders",
      delivery: "enableDeliveryOrders",
      reservation: "enableTableReservation",
    };

    const fieldName = fieldMap[feature];
    if (!fieldName) {
      throw new Error(`Invalid service feature: ${feature}`);
    }

    const updateFields = {
      [fieldName]: enabled,
    };

    await storeConfigService.updateCurrentConfig(storeId, updateFields);

    const action = enabled ? "enabled" : "disabled";
    const emoji = enabled ? "✅" : "❌";

    return {
      success: true,
      message: `${emoji} ${
        feature.charAt(0).toUpperCase() + feature.slice(1)
      } service ${action}.`,
      data: updateFields,
    };
  }

  /**
   * Tool: Get store status
   */
  async getStoreStatus(storeId) {
    const config = await storeConfigService.getStoreConfig(storeId);

    if (!config) {
      throw new Error(`Store not found with ID: ${storeId}`);
    }

    const current = config.current;
    const isOpen = this.isStoreCurrentlyOpen(current);
    const isTempClosed =
      current.tempClosed &&
      (current.tempClosedTill ? Date.now() < current.tempClosedTill : true);

    let status = "🏪 **Store Status**\n";
    status += `📍 Store: ${current.storeName}\n`;
    status += `⏰ Hours: ${current.openTime} - ${current.closeTime}\n`;

    if (isTempClosed) {
      const reopenTime = current.tempClosedTill
        ? new Date(current.tempClosedTill).toLocaleTimeString("en-US", {
            hour: "2-digit",
            minute: "2-digit",
            hour12: false,
          })
        : "manually";
      status += `🚪 Status: Temporarily Closed (reopens at ${reopenTime})\n`;
      status += `💬 Message: ${current.tempCloseMessage}\n`;
    } else {
      status += `🚪 Status: ${isOpen ? "Open" : "Closed"}\n`;
    }

    status += `💰 Min Delivery: $${current.minimumOrderForDelivery}\n`;
    status += `${current.enableCollectionOrders ? "✅" : "❌"} Collection: ${
      current.enableCollectionOrders ? "Enabled" : "Disabled"
    }\n`;
    status += `${current.enableDeliveryOrders ? "✅" : "❌"} Delivery: ${
      current.enableDeliveryOrders ? "Enabled" : "Disabled"
    }\n`;
    status += `${current.enableTableReservation ? "✅" : "❌"} Reservations: ${
      current.enableTableReservation ? "Enabled" : "Disabled"
    }\n`;

    // Add new configuration fields
    status += `💬 Welcome: "${current.welcomeMessage || "Not set"}"\n`;

    if (current.giftCard) {
      status += `🎁 Gift Cards: ${
        current.giftCard.enabled ? "Enabled" : "Disabled"
      }`;
      if (current.giftCard.enabled) {
        status += ` ($${current.giftCard.minValue}-$${current.giftCard.maxValue})`;
      }
      status += `\n`;
    } else {
      status += `🎁 Gift Cards: Not configured\n`;
    }

    status += `⭐ Loyalty Points: ${
      current.loyaltyPointsEnabled ? "Enabled" : "Disabled"
    }\n`;

    if (current.reservationSlots && current.reservationSlots.length > 0) {
      status += `📅 Reservation Slots: `;
      status += current.reservationSlots
        .map(
          (slot) => `${slot.start}-${slot.end} (${slot.maxReservations} spots)`
        )
        .join(", ");
    }

    return {
      success: true,
      message: status,
      data: config,
    };
  }

  /**
   * Tool: Reopen store
   */
  async reopenStore(storeId) {
    const config = await storeConfigService.getStoreConfig(storeId);

    if (!config) {
      throw new Error(`Store not found with ID: ${storeId}`);
    }

    if (!config.current.tempClosed) {
      return {
        success: true,
        message: "ℹ️ Store is already open.",
        data: { alreadyOpen: true },
      };
    }

    const updateFields = {
      tempClosed: false,
      tempClosedTill: null,
      tempCloseMessage: "",
    };

    await storeConfigService.updateCurrentConfig(storeId, updateFields);

    return {
      success: true,
      message: "✅ Store has been reopened and is now accepting orders.",
      data: updateFields,
    };
  }

  /**
   * Tool: Revert to default settings
   */
  async revertToDefault(storeId, { specificField } = {}) {
    await storeConfigService.revertToDefault(storeId, specificField);

    if (specificField) {
      return {
        success: true,
        message: `✅ ${specificField} has been reverted to default setting.`,
        data: { revertedField: specificField },
      };
    } else {
      return {
        success: true,
        message:
          "✅ All store settings have been reverted to default configuration.",
        data: { revertedAll: true },
      };
    }
  }

  /**
   * Get help message with available commands
   */
  getHelpMessage() {
    const help = `🤖 **FVK Store Management Bot**

**Available Commands:**

🏪 **Store Status**
• \`/status\` - Get current store status
• \`status\` - Check store information

🚪 **Store Control**  
• \`close store for 10 mins\` - Temporarily close store
• \`reopen store\` - Reopen closed store
• \`/reopen\` - Reopen store command

⏰ **Hours Management**
• \`set hours 09:00 22:00\` - Set opening hours
• \`change opening time to 08:00\` - Set opening time
• \`set closing time to 23:00\` - Set closing time

💰 **Order Settings**
• \`set minimum order 15\` - Set min delivery amount
• \`change minimum order to 20\` - Update min order

🔧 **Service Control**
• \`enable delivery\` - Enable delivery service
• \`disable collection\` - Disable takeaway
• \`turn on reservations\` - Enable table booking

🔄 **Reset Settings**
• \`revert to default\` - Reset all to defaults
• \`reset minimum order to default\` - Reset specific field

💬 **Welcome Message**
• \`set welcome message "Welcome to our store!"\` - Update greeting
• \`change welcome message "Hello customers!"\` - Change welcome text

🎁 **Gift Cards**
• \`enable gift cards\` - Enable gift card feature
• \`disable gift cards\` - Disable gift cards
• \`set gift card minimum 10\` - Set minimum value
• \`set gift card maximum 100\` - Set maximum value
• \`gift card values 10 100\` - Set min and max values

⭐ **Loyalty Points**
• \`enable loyalty points\` - Turn on loyalty program
• \`disable loyalty points\` - Turn off loyalty program
• \`activate loyalty program\` - Enable loyalty system

❓ **Help**
• \`/help\` - Show this help message
• \`help\` - Display available commands

**Examples:**
• "Close the takeaway for 30 minutes"
• "Set minimum order value to 25" 
• "Enable delivery service"
• "Set welcome message \"Welcome to our amazing store!\""
• "Enable gift cards with minimum 10 and maximum 100"
• "Turn on loyalty points program"
• "What's the current status?"`;

    return {
      success: true,
      message: help,
      data: { helpDisplayed: true },
    };
  }

  /**
   * Helper: Check if store is currently open based on time
   */
  isStoreCurrentlyOpen(settings) {
    const now = new Date();
    const currentTime = now.getHours() * 60 + now.getMinutes();

    const [openHours, openMinutes] = settings.openTime.split(":").map(Number);
    const [closeHours, closeMinutes] = settings.closeTime
      .split(":")
      .map(Number);

    const openTime = openHours * 60 + openMinutes;
    const closeTime = closeHours * 60 + closeMinutes;

    if (closeTime > openTime) {
      // Same day (e.g., 9:00 to 22:00)
      return currentTime >= openTime && currentTime <= closeTime;
    } else {
      // Crosses midnight (e.g., 22:00 to 02:00)
      return currentTime >= openTime || currentTime <= closeTime;
    }
  }

  /**
   * Tool: Update welcome message
   */
  async updateWelcomeMessage(storeId, { welcomeMessage, generateCatchy, theme }) {
    try {
      const config = await storeConfigService.getStoreConfig(storeId);
      if (!config) {
        return {
          success: false,
          message: `❌ Store ${storeId} not found`,
        };
      }

      let finalMessage = welcomeMessage;

      // Generate catchy message if requested
      if (generateCatchy && theme) {
        finalMessage = this.generateCatchyWelcomeMessage(theme);
      }

      if (!finalMessage) {
        return {
          success: false,
          message: `❌ No welcome message provided. Use quotes for custom messages or specify a theme for AI generation.`,
        };
      }

      // Update the welcome message
      await storeConfigService.updateCurrentConfig(storeId, {
        welcomeMessage: finalMessage,
      });

      logger.info(
        `Updated welcome message for store ${storeId}: "${finalMessage}"`
      );

      const responseMessage = generateCatchy 
        ? `✅ Generated and set catchy welcome message: "${finalMessage}"`
        : `✅ Welcome message updated to: "${finalMessage}"`;

      return {
        success: true,
        message: responseMessage,
        data: {
          storeId,
          welcomeMessage: finalMessage,
          generated: !!generateCatchy,
          theme: theme || null,
          updatedAt: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error(
        `Error updating welcome message for store ${storeId}:`,
        error
      );
      return {
        success: false,
        message: "❌ Failed to update welcome message. Please try again.",
      };
    }
  }

  /**
   * Tool: Update gift card configuration
   */
  async updateGiftCardConfig(storeId, parameters) {
    try {
      const config = await storeConfigService.getStoreConfig(storeId);
      if (!config) {
        return {
          success: false,
          message: `❌ Store ${storeId} not found`,
        };
      }

      const updates = {};
      let message = "";

      // Handle enabled/disabled
      if (parameters.enabled !== undefined) {
        updates["giftCard.enabled"] = parameters.enabled;
        message += `Gift cards ${parameters.enabled ? "enabled" : "disabled"}`;
      }

      // Handle min/max values
      if (parameters.minValue !== undefined) {
        updates["giftCard.minValue"] = parameters.minValue;
        message += `${message ? ", " : ""}minimum value set to ${
          parameters.minValue
        }`;
      }

      if (parameters.maxValue !== undefined) {
        updates["giftCard.maxValue"] = parameters.maxValue;
        message += `${message ? ", " : ""}maximum value set to ${
          parameters.maxValue
        }`;
      }

      // Update the configuration
      await storeConfigService.updateCurrentConfig(storeId, updates);

      logger.info(`Updated gift card config for store ${storeId}:`, updates);

      return {
        success: true,
        message: `✅ Gift card configuration updated: ${message}`,
        data: {
          storeId,
          giftCardUpdates: updates,
          updatedAt: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error(
        `Error updating gift card config for store ${storeId}:`,
        error
      );
      return {
        success: false,
        message:
          "❌ Failed to update gift card configuration. Please try again.",
      };
    }
  }

  /**
   * Tool: Update loyalty points configuration
   */
  async updateLoyaltyPoints(storeId, { enabled }) {
    try {
      const config = await storeConfigService.getStoreConfig(storeId);
      if (!config) {
        return {
          success: false,
          message: `❌ Store ${storeId} not found`,
        };
      }

      // Update loyalty points setting
      await storeConfigService.updateCurrentConfig(storeId, {
        loyaltyPointsEnabled: enabled,
      });

      logger.info(
        `${
          enabled ? "Enabled" : "Disabled"
        } loyalty points for store ${storeId}`
      );

      return {
        success: true,
        message: `✅ Loyalty points ${
          enabled ? "enabled" : "disabled"
        } for your store`,
        data: {
          storeId,
          loyaltyPointsEnabled: enabled,
          updatedAt: new Date().toISOString(),
        },
      };
    } catch (error) {
      logger.error(
        `Error updating loyalty points for store ${storeId}:`,
        error
      );
      return {
        success: false,
        message:
          "❌ Failed to update loyalty points setting. Please try again.",
      };
    }
  }

  /**
   * Generate a catchy welcome message based on theme
   */
  generateCatchyWelcomeMessage(theme) {
    const themeKeywords = theme.toLowerCase().split(' ').filter(word => word.length > 2);
    
    // Welcome message templates based on common themes
    const templates = {
      pizza: [
        "🍕 Welcome to our pizza paradise! Get ready for a slice of heaven that'll make your taste buds dance!",
        "🍕 Ciao and welcome! Our hand-crafted pizzas are made with love and served with a smile. Buon appetito!",
        "🍕 Welcome pizza lover! From classic margherita to gourmet creations - we've got the perfect slice waiting for you!",
        "🍕 Step into our pizzeria paradise! Where every bite is a celebration of authentic flavors and crispy perfection!"
      ],
      burger: [
        "🍔 Welcome to burger bliss! Get ready to sink your teeth into juicy, mouth-watering perfection!",
        "🍔 Hey there, burger enthusiast! We're serving up happiness between two buns - welcome to flavor town!",
        "🍔 Welcome to our burger haven! Where every patty is grilled to perfection and every bite tells a delicious story!"
      ],
      coffee: [
        "☕ Welcome to our coffee corner! Where every cup is brewed with passion and served with warmth!",
        "☕ Hello coffee lover! Start your day right with our expertly crafted blends and cozy atmosphere!",
        "☕ Welcome to your daily dose of happiness! Premium beans, perfect brews, and friendly vibes await!"
      ],
      food: [
        "🍽️ Welcome to our culinary adventure! Where every dish is crafted with love and served with pride!",
        "🍽️ Hello food lover! Prepare your taste buds for an unforgettable journey of flavors and freshness!",
        "🍽️ Welcome to our kitchen of dreams! Where quality ingredients meet culinary passion!"
      ],
      restaurant: [
        "🍽️ Welcome to our restaurant family! Where great food meets warm hospitality!",
        "👨‍🍳 Welcome! We're delighted to serve you an extraordinary dining experience filled with flavor and joy!",
        "🌟 Welcome to our culinary home! Every meal is prepared with care, every guest treated like family!"
      ]
    };

    // Find matching theme
    let selectedTemplate = templates.food; // default
    
    for (const [key, messages] of Object.entries(templates)) {
      if (themeKeywords.some(keyword => keyword.includes(key) || key.includes(keyword))) {
        selectedTemplate = messages;
        break;
      }
    }

    // Check for specific food items mentioned
    if (themeKeywords.some(word => ['sushi', 'japanese', 'asian'].includes(word))) {
      selectedTemplate = [
        "🍣 Welcome to our Japanese kitchen! Experience authentic flavors and artful presentation!",
        "🥢 Konnichiwa! Welcome to our authentic Asian dining experience - fresh, flavorful, and unforgettable!"
      ];
    } else if (themeKeywords.some(word => ['mexican', 'tacos', 'burrito'].includes(word))) {
      selectedTemplate = [
        "🌮 ¡Bienvenidos! Welcome to our Mexican fiesta! Authentic flavors that'll transport you south of the border!",
        "🌶️ Welcome amigo! Get ready for a spicy adventure with our authentic Mexican cuisine!"
      ];
    } else if (themeKeywords.some(word => ['indian', 'curry', 'spice'].includes(word))) {
      selectedTemplate = [
        "🍛 Namaste! Welcome to our spice journey! Authentic Indian flavors that warm the heart and soul!",
        "🌶️ Welcome to our Indian kitchen! Where every curry tells a story and every spice sings with flavor!"
      ];
    }

    // If theme contains specific descriptive words, create custom message
    if (themeKeywords.some(word => ['fresh', 'healthy', 'organic'].includes(word))) {
      return "🌱 Welcome to our fresh & healthy kitchen! Where nutritious meets delicious in every bite!";
    }
    
    if (themeKeywords.some(word => ['fast', 'quick', 'speedy'].includes(word))) {
      return "⚡ Welcome to fast food done right! Quick service, quality ingredients, and flavors that won't disappoint!";
    }

    // Return a random template from the selected category
    return selectedTemplate[Math.floor(Math.random() * selectedTemplate.length)];
  }
}

module.exports = new MCPToolExecutor();
