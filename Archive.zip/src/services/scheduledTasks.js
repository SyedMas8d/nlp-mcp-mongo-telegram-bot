const cron = require("node-cron");
const storeConfigService = require("../database/storeConfigService");
const telegramService = require("../services/telegramService");
const logger = require("../utils/logger");

class ScheduledTasks {
  constructor() {
    this.tasks = new Map();
  }

  /**
   * Initialize all scheduled tasks
   */
  init() {
    // Check for expired store closures every minute
    this.scheduleStoreReopeningCheck();

    // Clean up old sessions every hour
    this.scheduleSessionCleanup();

    // Health check every 5 minutes
    this.scheduleHealthCheck();

    logger.info("Scheduled tasks initialized");
  }

  /**
   * Check and reopen expired temporarily closed stores
   */
  scheduleStoreReopeningCheck() {
    const task = cron.schedule("* * * * *", async () => {
      try {
        const expiredStores = await storeConfigService.getExpiredClosedStores();

        for (const store of expiredStores) {
          await this.reopenExpiredStore(store);
        }

        if (expiredStores.length > 0) {
          logger.info(`Reopened ${expiredStores.length} expired stores`);
        }
      } catch (error) {
        logger.error("Error in store reopening check:", error);
      }
    });

    this.tasks.set("storeReopeningCheck", task);
    logger.info("Store reopening check scheduled (every minute)");
  }

  /**
   * Reopen an expired store
   */
  async reopenExpiredStore(storeConfig) {
    try {
      const storeId = storeConfig.storeId;

      // Update store to open
      await storeConfigService.updateCurrentConfig(storeId, {
        tempClosed: false,
        tempClosedTill: null,
        tempCloseMessage: "",
      });

      logger.info(`Automatically reopened store ${storeId}`);

      // Optionally notify store owner via Telegram
      // This would require mapping storeId to user IDs
      await this.notifyStoreReopened(storeId);
    } catch (error) {
      logger.error(`Error reopening store ${storeConfig.storeId}:`, error);
    }
  }

  /**
   * Notify that store has been automatically reopened
   */
  async notifyStoreReopened(storeId) {
    try {
      // In production, you would have a mapping of store IDs to user IDs
      // For now, we'll just log it
      logger.info(`Store ${storeId} has been automatically reopened`);

      // Example: If you have user-store mapping
      // const ownerIds = await getUsersForStore(storeId);
      // for (const userId of ownerIds) {
      //   await telegramService.sendMessage(userId,
      //     `🏪 Your store has been automatically reopened and is now accepting orders.`
      //   );
      // }
    } catch (error) {
      logger.error(`Error notifying store reopening for ${storeId}:`, error);
    }
  }

  /**
   * Clean up old user sessions
   */
  scheduleSessionCleanup() {
    const task = cron.schedule("0 * * * *", async () => {
      try {
        const botController = require("../controllers/botController");
        botController.cleanupOldSessions();
        logger.info("Cleaned up old user sessions");
      } catch (error) {
        logger.error("Error in session cleanup:", error);
      }
    });

    this.tasks.set("sessionCleanup", task);
    logger.info("Session cleanup scheduled (every hour)");
  }

  /**
   * Health check for database and services
   */
  scheduleHealthCheck() {
    const task = cron.schedule("*/5 * * * *", async () => {
      try {
        const dbConnection = require("../database/connection");
        const isHealthy = await dbConnection.ping();

        if (!isHealthy) {
          logger.error("Health check failed: Database not responding");
        }
      } catch (error) {
        logger.error("Error in health check:", error);
      }
    });

    this.tasks.set("healthCheck", task);
    logger.info("Health check scheduled (every 5 minutes)");
  }

  /**
   * Schedule custom task
   */
  addCustomTask(name, cronPattern, taskFunction) {
    try {
      const task = cron.schedule(cronPattern, taskFunction);
      this.tasks.set(name, task);
      logger.info(
        `Custom task '${name}' scheduled with pattern: ${cronPattern}`
      );
      return true;
    } catch (error) {
      logger.error(`Error scheduling custom task '${name}':`, error);
      return false;
    }
  }

  /**
   * Stop all scheduled tasks
   */
  stopAllTasks() {
    for (const [name, task] of this.tasks.entries()) {
      task.stop();
      logger.info(`Stopped scheduled task: ${name}`);
    }
    this.tasks.clear();
  }

  /**
   * Stop specific task
   */
  stopTask(taskName) {
    const task = this.tasks.get(taskName);
    if (task) {
      task.stop();
      this.tasks.delete(taskName);
      logger.info(`Stopped scheduled task: ${taskName}`);
      return true;
    }
    return false;
  }

  /**
   * Get status of all tasks
   */
  getTaskStatus() {
    const status = {};
    for (const [name, task] of this.tasks.entries()) {
      status[name] = {
        running: task.running || false,
        pattern: task.options?.pattern || "unknown",
      };
    }
    return status;
  }
}

module.exports = new ScheduledTasks();
