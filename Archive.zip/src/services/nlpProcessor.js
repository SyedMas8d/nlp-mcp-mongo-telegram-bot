const logger = require("../utils/logger");

// Intent patterns for natural language processing
const intentPatterns = {
  CLOSE_STORE: [
    /close.*?(takeaway|store|shop|restaurant).*?(\d+)\s*(min|minutes|hrs|hours)/i,
    /shut.*?(down|off).*?(\d+)\s*(min|minutes|hrs|hours)/i,
    /temporarily.*?close.*?(\d+)\s*(min|minutes|hrs|hours)/i,
    /close.*?for.*?(\d+)\s*(min|minutes|hrs|hours)/i,
  ],

  UPDATE_MINIMUM_ORDER: [
    /change.*?minimum.*?order.*?(\d+)/i,
    /update.*?minimum.*?delivery.*?(\d+)/i,
    /set.*?minimum.*?order.*?(\d+)/i,
    /minimum.*?order.*?(\d+)/i,
    /min.*?order.*?(\d+)/i,
  ],

  UPDATE_STORE_HOURS: [
    /change.*?hours.*?(\d{1,2}):(\d{2}).*?(\d{1,2}):(\d{2})/i,
    /set.*?opening.*?(\d{1,2}):(\d{2})/i,
    /set.*?closing.*?(\d{1,2}):(\d{2})/i,
    /open.*?(\d{1,2}):(\d{2}).*?close.*?(\d{1,2}):(\d{2})/i,
    /hours.*?(\d{1,2}):(\d{2}).*?(\d{1,2}):(\d{2})/i,
  ],

  TOGGLE_SERVICE: [
    /(enable|disable).*?(collection|delivery|takeaway|reservation)/i,
    /turn\s+(on|off).*?(collection|delivery|takeaway|reservation)/i,
    /(start|stop).*?(collection|delivery|reservation)/i,
    /(activate|deactivate).*?(collection|delivery|reservation)/i,
  ],

  GET_STATUS: [
    /status/i,
    /current.*?(config|settings)/i,
    /show.*?store.*?(info|details)/i,
    /what.*?(open|closed|available)/i,
    /store.*?info/i,
    /check.*?status/i,
  ],

  REOPEN_STORE: [
    /reopen/i,
    /open.*?(store|shop|restaurant)/i,
    /resume.*?operations/i,
    /start.*?taking.*?orders/i,
    /back.*?online/i,
    /activate.*?store/i,
  ],

  REVERT_TO_DEFAULT: [
    /revert.*?default/i,
    /reset.*?(default|original)/i,
    /restore.*?(default|original)/i,
    /back.*?default/i,
    /factory.*?reset/i,
    /default.*?settings/i,
  ],

  HELP: [/help/i, /commands/i, /what.*?can.*?do/i, /how.*?use/i, /start/i],

  UPDATE_WELCOME_MESSAGE: [
    /change.*?welcome.*?message.*?"(.+?)"/i,
    /set.*?welcome.*?message.*?"(.+?)"/i,
    /update.*?welcome.*?"(.+?)"/i,
    /welcome.*?message.*?"(.+?)"/i,
    /greeting.*?message.*?"(.+?)"/i,
    // AI-generated catchy messages
    /set.*?catchy.*?welcome.*?message.*?with\s+(.+)/i,
    /generate.*?welcome.*?message.*?with\s+(.+)/i,
    /create.*?catchy.*?welcome.*?for\s+(.+)/i,
    /make.*?welcome.*?message.*?about\s+(.+)/i,
    /catchy.*?welcome.*?message.*?(.+)/i,
  ],

  UPDATE_GIFT_CARD: [
    /(enable|disable).*?gift.*?card/i,
    /turn\s+(on|off).*?gift.*?card/i,
    /(activate|deactivate).*?gift.*?card/i,
    /gift.*?card.*?(min|minimum).*?(\d+)/i,
    /gift.*?card.*?(max|maximum).*?(\d+)/i,
    /gift.*?card.*?(\d+).*?(\d+)/i,
  ],

  UPDATE_LOYALTY_POINTS: [
    /(enable|disable).*?loyalty.*?points/i,
    /turn\s+(on|off).*?loyalty.*?points/i,
    /(activate|deactivate).*?loyalty/i,
    /loyalty.*?points.*?(on|off|enable|disable)/i,
    /(start|stop).*?loyalty.*?program/i,
  ],
};

class NLPProcessor {
  /**
   * Parse duration from text (returns minutes)
   */
  parseDuration(text) {
    const patterns = [
      { regex: /(\d+)\s*(min|minutes)/i, multiplier: 1 },
      { regex: /(\d+)\s*(hrs|hours|h)/i, multiplier: 60 },
      { regex: /(\d+\.?\d*)\s*(hrs|hours|h)/i, multiplier: 60 },
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern.regex);
      if (match) {
        return Math.round(parseFloat(match[1]) * pattern.multiplier);
      }
    }
    return null;
  }

  /**
   * Extract numeric values from text
   */
  extractNumbers(text) {
    const matches = text.match(/\d+\.?\d*/g);
    return matches ? matches.map((m) => parseFloat(m)) : [];
  }

  /**
   * Extract time format (HH:MM) from text
   */
  extractTimes(text) {
    const timePattern = /(\d{1,2}):(\d{2})/g;
    const times = [];
    let match;

    while ((match = timePattern.exec(text)) !== null) {
      const hours = parseInt(match[1]);
      const minutes = parseInt(match[2]);

      if (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 59) {
        times.push(
          `${hours.toString().padStart(2, "0")}:${minutes
            .toString()
            .padStart(2, "0")}`
        );
      }
    }

    return times;
  }

  /**
   * Extract service feature from text
   */
  extractServiceFeature(text) {
    const serviceMap = {
      collection: "collection",
      takeaway: "collection",
      delivery: "delivery",
      reservation: "reservation",
      reservations: "reservation",
      booking: "reservation",
      bookings: "reservation",
    };

    const words = text.toLowerCase().split(/\s+/);
    for (const word of words) {
      if (serviceMap[word]) {
        return serviceMap[word];
      }
    }
    return null;
  }

  /**
   * Detect intent from user message
   */
  detectIntent(messageText) {
    const text = messageText.toLowerCase().trim();

    // Check each intent pattern
    for (const [intent, patterns] of Object.entries(intentPatterns)) {
      for (const pattern of patterns) {
        const match = text.match(pattern);
        if (match) {
          return this.buildIntentMatch(intent, text, match);
        }
      }
    }

    // If no pattern matches, return unknown intent
    return {
      intent: "UNKNOWN",
      confidence: 0,
      parameters: {},
      originalText: messageText,
    };
  }

  /**
   * Build intent match object with extracted parameters
   */
  buildIntentMatch(intent, text, regexMatch) {
    const parameters = {};
    let confidence = 0.8; // Base confidence

    switch (intent) {
      case "CLOSE_STORE":
        const duration = this.parseDuration(text);
        if (duration) {
          parameters.durationMinutes = duration;
          confidence = 0.9;
        }

        // Extract reason if present
        const reasonMatch = text.match(
          /(?:because|reason|for)\s+(.+?)(?:\s+for\s+\d+|$)/i
        );
        if (reasonMatch) {
          parameters.reason = reasonMatch[1].trim();
        }
        break;

      case "UPDATE_MINIMUM_ORDER":
        const numbers = this.extractNumbers(text);
        if (numbers.length > 0) {
          parameters.minimumAmount = numbers[0];
          confidence = 0.9;
        }
        break;

      case "UPDATE_STORE_HOURS":
        const times = this.extractTimes(text);
        if (times.length >= 2) {
          parameters.openTime = times[0];
          parameters.closeTime = times[1];
          confidence = 0.95;
        } else if (times.length === 1) {
          // Try to determine if it's opening or closing time based on context
          if (text.includes("open") || text.includes("start")) {
            parameters.openTime = times[0];
          } else if (text.includes("close") || text.includes("end")) {
            parameters.closeTime = times[0];
          }
          confidence = 0.8;
        }
        break;

      case "TOGGLE_SERVICE":
        const feature = this.extractServiceFeature(text);
        if (feature) {
          parameters.feature = feature;

          // Determine if enabling or disabling
          if (
            text.includes("enable") ||
            text.includes("turn on") ||
            text.includes("start") ||
            text.includes("activate")
          ) {
            parameters.enabled = true;
          } else if (
            text.includes("disable") ||
            text.includes("turn off") ||
            text.includes("stop") ||
            text.includes("deactivate")
          ) {
            parameters.enabled = false;
          }
          confidence = 0.85;
        }
        break;

      case "REVERT_TO_DEFAULT":
        // Check if specific field is mentioned
        const fieldMatch =
          text.match(/revert\s+(.+?)\s+to\s+default/i) ||
          text.match(/reset\s+(.+?)\s+to\s+default/i);
        if (fieldMatch) {
          parameters.specificField = fieldMatch[1].trim();
          confidence = 0.9;
        }
        break;

      case "UPDATE_WELCOME_MESSAGE":
        // Check for AI-generated catchy message requests first
        let catchyMatch = text.match(/(?:catchy|generate|create|make).*?welcome.*?(?:with|about|for)\s+(.+)/i);
        if (catchyMatch) {
          parameters.generateCatchy = true;
          parameters.theme = catchyMatch[1].trim();
          confidence = 0.9;
        } else {
          // Check for catchy message without explicit keywords (e.g., "catchy welcome message pizza")
          catchyMatch = text.match(/catchy.*?welcome.*?message\s+(.+)/i);
          if (catchyMatch) {
            parameters.generateCatchy = true;
            parameters.theme = catchyMatch[1].trim();
            confidence = 0.9;
          } else {
            // Extract welcome message from quotes (traditional method)
            const welcomeMessageMatch = text.match(/"(.+?)"/);
            if (welcomeMessageMatch) {
              parameters.welcomeMessage = welcomeMessageMatch[1];
              confidence = 0.9;
            }
          }
        }
        break;

      case "UPDATE_GIFT_CARD":
        // Check if enabling or disabling
        if (
          text.includes("enable") ||
          text.includes("turn on") ||
          text.includes("activate")
        ) {
          parameters.enabled = true;
          confidence = 0.85;
        } else if (
          text.includes("disable") ||
          text.includes("turn off") ||
          text.includes("deactivate")
        ) {
          parameters.enabled = false;
          confidence = 0.85;
        }

        // Extract min and max values
        const giftCardNumbers = this.extractNumbers(text);
        if (giftCardNumbers.length >= 2) {
          parameters.minValue = Math.min(...giftCardNumbers);
          parameters.maxValue = Math.max(...giftCardNumbers);
          confidence = 0.9;
        } else if (giftCardNumbers.length === 1) {
          if (text.includes("min")) {
            parameters.minValue = giftCardNumbers[0];
          } else if (text.includes("max")) {
            parameters.maxValue = giftCardNumbers[0];
          }
          confidence = 0.8;
        }
        break;

      case "UPDATE_LOYALTY_POINTS":
        // Check if enabling or disabling
        if (
          text.includes("enable") ||
          text.includes("turn on") ||
          text.includes("activate") ||
          text.includes("start")
        ) {
          parameters.enabled = true;
          confidence = 0.85;
        } else if (
          text.includes("disable") ||
          text.includes("turn off") ||
          text.includes("deactivate") ||
          text.includes("stop")
        ) {
          parameters.enabled = false;
          confidence = 0.85;
        }
        break;

      default:
        confidence = 0.7;
    }

    return {
      intent,
      confidence,
      parameters,
      originalText: text,
      regexMatch,
    };
  }

  /**
   * Validate extracted parameters
   */
  validateParameters(intent, parameters) {
    const errors = [];

    switch (intent) {
      case "CLOSE_STORE":
        if (!parameters.durationMinutes) {
          errors.push("Duration is required for closing store");
        } else if (
          parameters.durationMinutes < 1 ||
          parameters.durationMinutes > 1440
        ) {
          errors.push("Duration must be between 1 minute and 24 hours");
        }
        break;

      case "UPDATE_MINIMUM_ORDER":
        if (!parameters.minimumAmount) {
          errors.push("Minimum amount is required");
        } else if (
          parameters.minimumAmount < 0 ||
          parameters.minimumAmount > 1000
        ) {
          errors.push("Minimum amount must be between 0 and 1000");
        }
        break;

      case "UPDATE_STORE_HOURS":
        if (!parameters.openTime && !parameters.closeTime) {
          errors.push("At least one time (opening or closing) is required");
        }
        break;

      case "TOGGLE_SERVICE":
        if (!parameters.feature) {
          errors.push(
            "Service feature is required (collection, delivery, or reservation)"
          );
        }
        if (parameters.enabled === undefined) {
          errors.push("Enable/disable action is required");
        }
        break;

      case "UPDATE_WELCOME_MESSAGE":
        // Check if either traditional message or AI generation parameters are provided
        if (!parameters.welcomeMessage && !parameters.generateCatchy) {
          errors.push(
            "Welcome message is required (use quotes around the message or request AI generation)"
          );
        } else if (parameters.welcomeMessage && parameters.welcomeMessage.length > 200) {
          errors.push("Welcome message must be 200 characters or less");
        } else if (parameters.generateCatchy && !parameters.theme) {
          errors.push("Theme is required for AI-generated welcome messages");
        }
        break;

      case "UPDATE_GIFT_CARD":
        if (parameters.enabled !== undefined) {
          // If just enabling/disabling, no other validation needed
        } else if (
          parameters.minValue !== undefined ||
          parameters.maxValue !== undefined
        ) {
          if (parameters.minValue !== undefined && parameters.minValue < 0) {
            errors.push("Minimum gift card value must be positive");
          }
          if (parameters.maxValue !== undefined && parameters.maxValue < 1) {
            errors.push("Maximum gift card value must be at least 1");
          }
          if (
            parameters.minValue !== undefined &&
            parameters.maxValue !== undefined &&
            parameters.minValue >= parameters.maxValue
          ) {
            errors.push("Minimum value must be less than maximum value");
          }
        } else {
          errors.push(
            "Please specify to enable/disable gift cards or provide min/max values"
          );
        }
        break;

      case "UPDATE_LOYALTY_POINTS":
        if (parameters.enabled === undefined) {
          errors.push("Please specify to enable or disable loyalty points");
        }
        break;
    }

    return errors;
  }
}

module.exports = new NLPProcessor();
