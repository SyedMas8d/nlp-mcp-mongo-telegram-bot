const axios = require("axios");
const logger = require("../utils/logger");

class TelegramService {
  constructor() {
    this.botToken = process.env.TELEGRAM_BOT_TOKEN;
    this.apiUrl = `https://api.telegram.org/bot${this.botToken}`;

    if (!this.botToken) {
      logger.error("TELEGRAM_BOT_TOKEN is not set in environment variables");
    }
  }

  /**
   * Send message to Telegram chat
   */
  async sendMessage(chatId, text, options = {}) {
    try {
      const payload = {
        chat_id: chatId,
        text: text,
        parse_mode: options.parseMode || "Markdown",
        disable_web_page_preview: options.disableWebPreview || true,
        ...options,
      };

      const response = await axios.post(`${this.apiUrl}/sendMessage`, payload);

      if (response.data.ok) {
        logger.info(`Message sent to chat ${chatId}`);
        return response.data.result;
      } else {
        throw new Error(`Telegram API error: ${response.data.description}`);
      }
    } catch (error) {
      logger.error(`Error sending message to chat ${chatId}:`, error.message);
      throw error;
    }
  }

  /**
   * Send typing action to show bot is processing
   */
  async sendChatAction(chatId, action = "typing") {
    try {
      await axios.post(`${this.apiUrl}/sendChatAction`, {
        chat_id: chatId,
        action: action,
      });
    } catch (error) {
      logger.error(`Error sending chat action to ${chatId}:`, error.message);
      // Don't throw error for chat actions as it's not critical
    }
  }

  /**
   * Set bot commands (for Telegram menu)
   */
  async setBotCommands() {
    const commands = [
      {
        command: "start",
        description: "Initialize bot and show welcome message",
      },
      {
        command: "status",
        description: "Get current store status and configuration",
      },
      {
        command: "help",
        description: "Show all available commands and usage examples",
      },
      { command: "reopen", description: "Reopen store immediately" },
      { command: "welcome", description: "Update store welcome message" },
      { command: "giftcard", description: "Manage gift card settings" },
      { command: "loyalty", description: "Toggle loyalty points program" },
    ];

    try {
      const response = await axios.post(`${this.apiUrl}/setMyCommands`, {
        commands: commands,
      });

      if (response.data.ok) {
        logger.info("Bot commands set successfully");
        return true;
      } else {
        throw new Error(`Failed to set commands: ${response.data.description}`);
      }
    } catch (error) {
      logger.error("Error setting bot commands:", error.message);
      return false;
    }
  }

  /**
   * Set webhook URL
   */
  async setWebhook(webhookUrl) {
    try {
      const response = await axios.post(`${this.apiUrl}/setWebhook`, {
        url: webhookUrl,
        allowed_updates: ["message", "callback_query"],
      });

      if (response.data.ok) {
        logger.info(`Webhook set to: ${webhookUrl}`);
        return true;
      } else {
        throw new Error(`Failed to set webhook: ${response.data.description}`);
      }
    } catch (error) {
      logger.error("Error setting webhook:", error.message);
      return false;
    }
  }

  /**
   * Delete webhook (for development)
   */
  async deleteWebhook() {
    try {
      const response = await axios.post(`${this.apiUrl}/deleteWebhook`);

      if (response.data.ok) {
        logger.info("Webhook deleted successfully");
        return true;
      } else {
        throw new Error(
          `Failed to delete webhook: ${response.data.description}`
        );
      }
    } catch (error) {
      logger.error("Error deleting webhook:", error.message);
      return false;
    }
  }

  /**
   * Get webhook info
   */
  async getWebhookInfo() {
    try {
      const response = await axios.get(`${this.apiUrl}/getWebhookInfo`);

      if (response.data.ok) {
        return response.data.result;
      } else {
        throw new Error(
          `Failed to get webhook info: ${response.data.description}`
        );
      }
    } catch (error) {
      logger.error("Error getting webhook info:", error.message);
      throw error;
    }
  }

  /**
   * Get bot information
   */
  async getBotInfo() {
    try {
      const response = await axios.get(`${this.apiUrl}/getMe`);

      if (response.data.ok) {
        return response.data.result;
      } else {
        throw new Error(`Failed to get bot info: ${response.data.description}`);
      }
    } catch (error) {
      logger.error("Error getting bot info:", error.message);
      throw error;
    }
  }

  /**
   * Process incoming Telegram update
   */
  async processUpdate(update) {
    try {
      if (update.message) {
        return await this.processMessage(update.message);
      } else if (update.callback_query) {
        return await this.processCallbackQuery(update.callback_query);
      } else {
        logger.warn("Unknown update type received:", JSON.stringify(update));
        return { processed: false, reason: "Unknown update type" };
      }
    } catch (error) {
      logger.error("Error processing update:", error);
      throw error;
    }
  }

  /**
   * Process incoming message
   */
  async processMessage(message) {
    const chatId = message.chat.id;
    const userId = message.from.id;
    const messageText = message.text;

    logger.info(
      `Received message from user ${userId} in chat ${chatId}: ${messageText}`
    );

    // Send typing indicator
    await this.sendChatAction(chatId, "typing");

    return {
      processed: true,
      chatId,
      userId,
      messageText,
      messageType: "text",
    };
  }

  /**
   * Process callback query (inline keyboard buttons)
   */
  async processCallbackQuery(callbackQuery) {
    const chatId = callbackQuery.message.chat.id;
    const userId = callbackQuery.from.id;
    const data = callbackQuery.data;

    logger.info(`Received callback query from user ${userId}: ${data}`);

    // Answer callback query to remove loading state
    await axios.post(`${this.apiUrl}/answerCallbackQuery`, {
      callback_query_id: callbackQuery.id,
    });

    return {
      processed: true,
      chatId,
      userId,
      data,
      messageType: "callback",
    };
  }

  /**
   * Format error message for user
   */
  formatErrorMessage(error) {
    if (error.message.includes("Store not found")) {
      return "❌ Store not found. Please check your store ID.";
    } else if (error.message.includes("Duration is required")) {
      return '❌ Please specify a valid duration (e.g., "10 mins", "2 hours").';
    } else if (error.message.includes("Minimum amount is required")) {
      return '❌ Please specify a valid amount (e.g., "15", "20.50").';
    } else if (error.message.includes("At least one time")) {
      return '❌ Please use valid time format (e.g., "09:00", "22:30").';
    } else if (error.message.includes("Service feature is required")) {
      return "❌ Please specify a service: collection, delivery, or reservation.";
    } else {
      return "❌ Sorry, I couldn't process that request. Please try again or use /help for available commands.";
    }
  }

  /**
   * Validate Telegram webhook security
   */
  validateWebhookSecurity(req) {
    // In production, you should validate the request using secret token
    const secretPath = process.env.TELEGRAM_WEBHOOK_SECRET || this.botToken;

    // Basic validation - in production, implement proper secret token validation
    return req.headers["content-type"] === "application/json";
  }
}

module.exports = new TelegramService();
