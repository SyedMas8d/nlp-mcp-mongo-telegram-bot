const nlpProcessor = require("../services/nlpProcessor");
const mcpToolExecutor = require("../services/mcpToolExecutor");
const telegramService = require("../services/telegramService");
const logger = require("../utils/logger");

class BotController {
  constructor() {
    // Store user sessions (in production, use Redis or database)
    this.userSessions = new Map();
  }

  /**
   * Main message processing function
   */
  async processUserMessage(userId, chatId, messageText) {
    try {
      // Get or create user session
      const session = this.getUserSession(userId);

      // Log the interaction
      logger.info(`Processing message from user ${userId}: "${messageText}"`);

      // Handle special commands first
      if (messageText.startsWith("/")) {
        return await this.handleSlashCommand(
          userId,
          chatId,
          messageText,
          session
        );
      }

      // Process natural language
      const intentMatch = nlpProcessor.detectIntent(messageText);
      logger.info(
        `Detected intent: ${intentMatch.intent} (confidence: ${intentMatch.confidence})`
      );

      // Validate parameters
      const validationErrors = nlpProcessor.validateParameters(
        intentMatch.intent,
        intentMatch.parameters
      );
      if (validationErrors.length > 0) {
        return {
          success: false,
          message: `❌ ${validationErrors.join(". ")}`,
        };
      }

      // Execute MCP tool
      const result = await mcpToolExecutor.executeTool(
        intentMatch.intent,
        intentMatch.parameters,
        session.storeId
      );

      // Update session with last interaction
      session.lastIntent = intentMatch.intent;
      session.lastInteraction = new Date();
      this.updateUserSession(userId, session);

      return result;
    } catch (error) {
      logger.error(`Error processing message from user ${userId}:`, error);

      return {
        success: false,
        message: telegramService.formatErrorMessage(error),
      };
    }
  }

  /**
   * Handle slash commands
   */
  async handleSlashCommand(userId, chatId, command, session) {
    const cmd = command.toLowerCase().split(" ")[0];
    const args = command.split(" ").slice(1);

    switch (cmd) {
      case "/start":
        return this.handleStartCommand(userId, session);

      case "/help":
        return mcpToolExecutor.getHelpMessage();

      case "/status":
        return await mcpToolExecutor.getStoreStatus(session.storeId);

      case "/reopen":
        return await mcpToolExecutor.reopenStore(session.storeId);

      case "/setstore":
        if (args.length === 0) {
          return {
            success: false,
            message: "❌ Please provide a store ID. Example: `/setstore 7409`",
          };
        }
        return this.setUserStoreId(userId, args[0]);

      default:
        return {
          success: false,
          message: "❌ Unknown command. Use /help to see available commands.",
        };
    }
  }

  /**
   * Handle /start command
   */
  handleStartCommand(userId, session) {
    const welcomeMessage = `🏪 **Welcome to FoohubAI Store Management Bot!**

Hi there! I'm your intelligent store management assistant. I can help you manage your store settings using simple natural language.

**🚀 Quick Setup:**
First, set your store ID with: \`/setstore YOUR_STORE_ID\`
Current store: \`${session.storeId || "Not set"}\`

**🎯 What I can do:**
• 🚪 **Store Control:** "close store for 30 minutes", "reopen store"
• ⏰ **Hours:** "set opening hours 9:00 to 22:00"  
• 💰 **Orders:** "set minimum order to $25"
• 🔧 **Services:** "disable delivery", "enable reservations"
• 📊 **Status:** "show store status"
• 🔄 **Reset:** "revert to default settings"

**💬 Try saying:**
• "What's the current status?"
• "Close store for 30 minutes"
• "Set minimum order to 20"
• "Enable delivery service"

Type \`/help\` for detailed commands or just talk to me naturally!

Ready to help manage your store! 🚀`;

    return {
      success: true,
      message: welcomeMessage,
    };
  }

  /**
   * Get user session (with default store ID)
   */
  getUserSession(userId) {
    if (!this.userSessions.has(userId)) {
      // Default session - in production, fetch from database
      const defaultSession = {
        userId,
        storeId: "7409", // Default store ID from your example
        createdAt: new Date(),
        lastInteraction: new Date(),
        lastIntent: null,
        preferences: {},
      };
      this.userSessions.set(userId, defaultSession);
      logger.info(`Created new session for user ${userId}`);
    }

    return this.userSessions.get(userId);
  }

  /**
   * Update user session
   */
  updateUserSession(userId, session) {
    session.lastInteraction = new Date();
    this.userSessions.set(userId, session);
  }

  /**
   * Set store ID for user
   */
  setUserStoreId(userId, storeId) {
    const session = this.getUserSession(userId);
    session.storeId = storeId;
    this.updateUserSession(userId, session);

    logger.info(`Updated store ID for user ${userId} to ${storeId}`);

    return {
      success: true,
      message: `✅ Store ID updated to ${storeId}. You can now manage this store.`,
    };
  }

  /**
   * Handle Telegram webhook
   */
  async handleTelegramWebhook(update) {
    try {
      // Process the update through Telegram service
      const processedUpdate = await telegramService.processUpdate(update);

      if (!processedUpdate.processed) {
        return { success: false, message: "Update not processed" };
      }

      const { chatId, userId, messageText } = processedUpdate;

      // Process the message through bot controller
      const result = await this.processUserMessage(userId, chatId, messageText);

      // Send response back to Telegram
      await telegramService.sendMessage(chatId, result.message);

      return { success: true, processed: true };
    } catch (error) {
      logger.error("Error handling Telegram webhook:", error);

      // Try to send error message to user if we have chat ID
      if (update.message?.chat?.id) {
        try {
          await telegramService.sendMessage(
            update.message.chat.id,
            "❌ Sorry, something went wrong. Please try again."
          );
        } catch (sendError) {
          logger.error("Failed to send error message:", sendError);
        }
      }

      return { success: false, error: error.message };
    }
  }

  /**
   * Clean up old sessions (call periodically)
   */
  cleanupOldSessions() {
    const now = new Date();
    const maxAge = 24 * 60 * 60 * 1000; // 24 hours

    for (const [userId, session] of this.userSessions.entries()) {
      if (now - session.lastInteraction > maxAge) {
        this.userSessions.delete(userId);
        logger.info(`Cleaned up old session for user ${userId}`);
      }
    }
  }

  /**
   * Get session stats (for monitoring)
   */
  getStats() {
    return {
      activeSessions: this.userSessions.size,
      sessions: Array.from(this.userSessions.values()).map((session) => ({
        userId: session.userId,
        storeId: session.storeId,
        lastInteraction: session.lastInteraction,
        lastIntent: session.lastIntent,
      })),
    };
  }
}

module.exports = new BotController();
