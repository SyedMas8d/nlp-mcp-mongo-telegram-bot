export interface StoreConfig {
  storeId: string;
  default: StoreSettings;
  current: StoreSettings;
  _id?: string;
  createdAt: string;
  updatedAt: string;
  __v?: number;
}

export interface StoreSettings {
  openTime: string;
  closeTime: string;
  tempClosed: boolean;
  tempClosedTill: number | null;
  tempCloseMessage: string;
  enableCollectionOrders: boolean;
  enableDeliveryOrders: boolean;
  enableTableReservation: boolean;
  reservationSlots: ReservationSlot[];
  minimumOrderForDelivery: number;
  storeName: string;
  storeLogo: string;
}

export interface ReservationSlot {
  start: string;
  end: string;
  maxReservations: number;
}

export interface MCPTool {
  name: string;
  description: string;
  parameters: Record<string, any>;
}

export interface CloseStoreTemporarily extends MCPTool {
  name: "close_store_temporarily";
  description: "Temporarily close store for specified duration";
  parameters: {
    storeId: string;
    durationMinutes: number;
    reason?: string;
  };
}

export interface UpdateMinimumOrder extends MCPTool {
  name: "update_minimum_order";
  description: "Change minimum order value for delivery";
  parameters: {
    storeId: string;
    minimumAmount: number;
  };
}

export interface GetStoreStatus extends MCPTool {
  name: "get_store_status";
  description: "Get current store configuration and status";
  parameters: {
    storeId: string;
  };
}

export interface ReopenStore extends MCPTool {
  name: "reopen_store";
  description: "Manually reopen temporarily closed store";
  parameters: {
    storeId: string;
  };
}

export interface RevertToDefault extends MCPTool {
  name: "revert_to_default";
  description: "Reset current settings to default configuration";
  parameters: {
    storeId: string;
    specificField?: string;
  };
}

export interface UpdateStoreHours extends MCPTool {
  name: "update_store_hours";
  description: "Modify store opening and closing hours";
  parameters: {
    storeId: string;
    openTime?: string;
    closeTime?: string;
  };
}

export interface ToggleServiceFeature extends MCPTool {
  name: "toggle_service_feature";
  description: "Enable or disable store services";
  parameters: {
    storeId: string;
    feature: "collection" | "delivery" | "reservation";
    enabled: boolean;
  };
}

export type ServiceFeature = "collection" | "delivery" | "reservation";

export interface TelegramMessage {
  message_id: number;
  from: {
    id: number;
    is_bot: boolean;
    first_name: string;
    last_name?: string;
    username?: string;
  };
  chat: {
    id: number;
    first_name?: string;
    last_name?: string;
    username?: string;
    type: string;
  };
  date: number;
  text: string;
}

export interface TelegramUpdate {
  update_id: number;
  message?: TelegramMessage;
  callback_query?: any;
}

export interface IntentMatch {
  intent: string;
  confidence: number;
  parameters: Record<string, any>;
}

export interface BotCommand {
  command: string;
  description: string;
}

export enum Intent {
  CLOSE_STORE = "CLOSE_STORE",
  UPDATE_MINIMUM_ORDER = "UPDATE_MINIMUM_ORDER",
  UPDATE_STORE_HOURS = "UPDATE_STORE_HOURS",
  TOGGLE_SERVICE = "TOGGLE_SERVICE",
  GET_STATUS = "GET_STATUS",
  REOPEN_STORE = "REOPEN_STORE",
  REVERT_TO_DEFAULT = "REVERT_TO_DEFAULT",
  HELP = "HELP",
  UNKNOWN = "UNKNOWN",
}
