require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

const logger = require("./utils/logger");
const dbConnection = require("./database/connection");
const botController = require("./controllers/botController");
const telegramService = require("./services/telegramService");
const scheduledTasks = require("./services/scheduledTasks");

class MCPServer {
  constructor() {
    this.app = express();
    this.port = process.env.PORT || 3000;
    this.setupMiddleware();
    this.setupRoutes();
    this.setupErrorHandling();
  }

  /**
   * Setup Express middleware
   */
  setupMiddleware() {
    // Security middleware
    this.app.use(helmet());

    // CORS configuration
    this.app.use(
      cors({
        origin:
          process.env.NODE_ENV === "production"
            ? ["https://your-domain.com"]
            : ["http://localhost:3000", "http://127.0.0.1:3000"],
        credentials: true,
      })
    );

    // Request parsing
    this.app.use(express.json({ limit: "10mb" }));
    this.app.use(express.urlencoded({ extended: true }));

    // Logging
    this.app.use(
      morgan("combined", {
        stream: {
          write: (message) => logger.info(message.trim()),
        },
      })
    );

    // Request ID for tracing
    this.app.use((req, res, next) => {
      req.id = Date.now().toString(36) + Math.random().toString(36).substr(2);
      next();
    });
  }

  /**
   * Setup application routes
   */
  setupRoutes() {
    // Health check endpoint
    this.app.get("/health", async (req, res) => {
      try {
        const dbHealthy = await dbConnection.ping();
        const botInfo = await telegramService.getBotInfo();

        res.json({
          status: "healthy",
          timestamp: new Date().toISOString(),
          database: dbHealthy ? "connected" : "disconnected",
          telegram: botInfo ? "connected" : "disconnected",
          version: process.env.npm_package_version || "1.0.0",
          uptime: process.uptime(),
        });
      } catch (error) {
        logger.error("Health check failed:", error);
        res.status(503).json({
          status: "unhealthy",
          error: error.message,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // Telegram webhook endpoint
    this.app.post("/webhook/telegram", async (req, res) => {
      try {
        logger.info(`Telegram webhook received: ${JSON.stringify(req.body)}`);

        // Validate request (basic validation)
        if (!telegramService.validateWebhookSecurity(req)) {
          return res.status(403).json({ error: "Unauthorized" });
        }

        const update = req.body;

        // Process update asynchronously
        setImmediate(async () => {
          try {
            await botController.handleTelegramWebhook(update);
          } catch (error) {
            logger.error("Error processing Telegram webhook:", error);
          }
        });

        // Respond quickly to Telegram
        res.status(200).json({ ok: true });
      } catch (error) {
        logger.error("Telegram webhook error:", error);
        res.status(500).json({ error: "Internal server error" });
      }
    });

    // MCP tools endpoint (for direct API access)
    this.app.post("/api/mcp/execute", async (req, res) => {
      try {
        const { intent, parameters, storeId } = req.body;

        if (!intent || !storeId) {
          return res.status(400).json({
            error: "Missing required fields: intent, storeId",
          });
        }

        const mcpToolExecutor = require("./services/mcpToolExecutor");
        const result = await mcpToolExecutor.executeTool(
          intent,
          parameters,
          storeId
        );

        res.json(result);
      } catch (error) {
        logger.error("MCP execute error:", error);
        res.status(500).json({
          success: false,
          error: error.message,
        });
      }
    });

    // Store management endpoints
    this.app.get("/api/stores/:storeId", async (req, res) => {
      try {
        const storeConfigService = require("./database/storeConfigService");
        const config = await storeConfigService.getStoreConfig(
          req.params.storeId
        );

        if (!config) {
          return res.status(404).json({ error: "Store not found" });
        }

        res.json(config);
      } catch (error) {
        logger.error("Get store error:", error);
        res.status(500).json({ error: error.message });
      }
    });

    // Bot stats endpoint (for monitoring)
    this.app.get("/api/admin/stats", (req, res) => {
      try {
        const stats = botController.getStats();
        const taskStatus = scheduledTasks.getTaskStatus();

        res.json({
          ...stats,
          tasks: taskStatus,
          server: {
            uptime: process.uptime(),
            memory: process.memoryUsage(),
            version: process.env.npm_package_version || "1.0.0",
          },
        });
      } catch (error) {
        logger.error("Stats error:", error);
        res.status(500).json({ error: error.message });
      }
    });

    // Webhook setup endpoint (for development)
    this.app.post("/api/admin/setup-webhook", async (req, res) => {
      try {
        const { webhookUrl } = req.body;

        if (!webhookUrl) {
          return res.status(400).json({ error: "Webhook URL is required" });
        }

        const success = await telegramService.setWebhook(webhookUrl);

        if (success) {
          await telegramService.setBotCommands();
          res.json({
            success: true,
            message: "Webhook and commands set successfully",
          });
        } else {
          res
            .status(500)
            .json({ success: false, error: "Failed to set webhook" });
        }
      } catch (error) {
        logger.error("Setup webhook error:", error);
        res.status(500).json({ error: error.message });
      }
    });

    // Default route
    this.app.get("/", (req, res) => {
      res.json({
        name: "FVK MCP Chatbot Server",
        version: process.env.npm_package_version || "1.0.0",
        status: "running",
        endpoints: {
          health: "/health",
          webhook: "/webhook/telegram",
          mcp: "/api/mcp/execute",
          stores: "/api/stores/:storeId",
          stats: "/api/admin/stats",
        },
      });
    });

    // 404 handler
    this.app.use("*", (req, res) => {
      res.status(404).json({
        error: "Not Found",
        message: "The requested endpoint does not exist",
      });
    });
  }

  /**
   * Setup error handling
   */
  setupErrorHandling() {
    // Global error handler
    this.app.use((error, req, res, next) => {
      logger.error("Unhandled error:", error);

      res.status(500).json({
        error: "Internal Server Error",
        message:
          process.env.NODE_ENV === "production"
            ? "Something went wrong"
            : error.message,
        requestId: req.id,
      });
    });

    // Process error handlers
    process.on("uncaughtException", (error) => {
      logger.error("Uncaught Exception:", error);
      process.exit(1);
    });

    process.on("unhandledRejection", (reason, promise) => {
      logger.error("Unhandled Rejection at:", promise, "reason:", reason);
    });
  }

  /**
   * Start the server
   */
  async start() {
    try {
      // Connect to database
      await dbConnection.connect();
      logger.info("Database connected successfully");

      // Initialize scheduled tasks
      scheduledTasks.init();

      // Start HTTP server
      this.server = this.app.listen(this.port, () => {
        logger.info(`MCP Server running on port ${this.port}`);
        logger.info(`Environment: ${process.env.NODE_ENV || "development"}`);

        if (process.env.NODE_ENV !== "production") {
          logger.info(`Health check: http://localhost:${this.port}/health`);
          logger.info(
            `Webhook URL: http://localhost:${this.port}/webhook/telegram`
          );
        }
      });

      // Graceful shutdown handling
      process.on("SIGTERM", () => this.shutdown());
      process.on("SIGINT", () => this.shutdown());
    } catch (error) {
      logger.error("Failed to start server:", error);
      process.exit(1);
    }
  }

  /**
   * Graceful shutdown
   */
  async shutdown() {
    logger.info("Shutting down server...");

    try {
      // Stop scheduled tasks
      scheduledTasks.stopAllTasks();

      // Close HTTP server
      if (this.server) {
        this.server.close();
      }

      // Close database connection
      await dbConnection.disconnect();

      logger.info("Server shutdown complete");
      process.exit(0);
    } catch (error) {
      logger.error("Error during shutdown:", error);
      process.exit(1);
    }
  }
}

// Start server if this file is run directly
if (require.main === module) {
  const server = new MCPServer();
  server.start();
}

module.exports = MCPServer;
