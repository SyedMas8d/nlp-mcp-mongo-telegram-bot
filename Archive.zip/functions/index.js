const { onRequest } = require("firebase-functions/v2/https");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const { setGlobalOptions } = require("firebase-functions/v2");

// Set global options for Firebase functions
setGlobalOptions({
  region: "us-central1",
  maxInstances: 10,
});

// Import the MCP Server
const MCPServer = require("../src/index");

// Create server instance
const server = new MCPServer();

// MCP Server endpoint for Firebase Functions
exports.mcpServer = onRequest(
  {
    cors: true,
    memory: "512MiB",
    timeoutSeconds: 60,
  },
  server.app
);

// Telegram webhook endpoint
exports.telegramWebhook = onRequest(
  {
    cors: true,
    memory: "256MiB",
    timeoutSeconds: 30,
  },
  (req, res) => {
    // Forward to the webhook route in the main server
    server.app(req, res);
  }
);

// Scheduled function to check and reopen stores
exports.checkStoreClosures = onSchedule("every 1 minutes", async (event) => {
  const storeConfigService = require("../src/database/storeConfigService");
  const logger = require("../src/utils/logger");

  try {
    const expiredStores = await storeConfigService.getExpiredClosedStores();

    for (const store of expiredStores) {
      await storeConfigService.updateCurrentConfig(store.storeId, {
        tempClosed: false,
        tempClosedTill: null,
        tempCloseMessage: "",
      });

      logger.info(`Auto-reopened store ${store.storeId}`);
    }

    if (expiredStores.length > 0) {
      logger.info(`Automatically reopened ${expiredStores.length} stores`);
    }
  } catch (error) {
    logger.error("Error in scheduled store closure check:", error);
  }
});

// Scheduled function for cleanup tasks
exports.cleanupTasks = onSchedule("every 1 hours", async (event) => {
  const botController = require("../src/controllers/botController");
  const logger = require("../src/utils/logger");

  try {
    // Clean up old user sessions
    botController.cleanupOldSessions();
    logger.info("Completed scheduled cleanup tasks");
  } catch (error) {
    logger.error("Error in scheduled cleanup:", error);
  }
});

// Health check function
exports.healthCheck = onRequest(
  {
    cors: true,
    memory: "128MiB",
    timeoutSeconds: 10,
  },
  async (req, res) => {
    try {
      const dbConnection = require("../src/database/connection");

      const health = {
        status: "healthy",
        timestamp: new Date().toISOString(),
        version: "1.0.0",
        database: "checking...",
      };

      try {
        const dbHealthy = await dbConnection.ping();
        health.database = dbHealthy ? "connected" : "disconnected";
      } catch (dbError) {
        health.database = "error";
        health.status = "degraded";
      }

      const statusCode = health.status === "healthy" ? 200 : 503;
      res.status(statusCode).json(health);
    } catch (error) {
      res.status(500).json({
        status: "unhealthy",
        error: error.message,
        timestamp: new Date().toISOString(),
      });
    }
  }
);
