#!/usr/bin/env node

require("dotenv").config();
const axios = require("axios");

async function setupTelegramWebhook() {
  const BOT_TOKEN = process.env.TELEGRAM_BOT_TOKEN;
  const WEBHOOK_URL = process.env.TELEGRAM_WEBHOOK_URL;

  if (!BOT_TOKEN) {
    console.error("❌ TELEGRAM_BOT_TOKEN is not set in environment variables");
    process.exit(1);
  }

  if (!WEBHOOK_URL) {
    console.error(
      "❌ TELEGRAM_WEBHOOK_URL is not set in environment variables"
    );
    process.exit(1);
  }

  const apiUrl = `https://api.telegram.org/bot${BOT_TOKEN}`;

  try {
    console.log("🔧 Setting up Telegram webhook...");
    console.log(`📡 Webhook URL: ${WEBHOOK_URL}`);

    // Set webhook
    const webhookResponse = await axios.post(`${apiUrl}/setWebhook`, {
      url: WEBHOOK_URL,
      allowed_updates: ["message", "callback_query"],
    });

    if (!webhookResponse.data.ok) {
      throw new Error(
        `Failed to set webhook: ${webhookResponse.data.description}`
      );
    }

    console.log("✅ Webhook set successfully");

    // Set bot commands
    const commands = [
      {
        command: "start",
        description: "Initialize bot and show welcome message",
      },
      {
        command: "status",
        description: "Get current store status and configuration",
      },
      {
        command: "help",
        description: "Show all available commands and usage examples",
      },
      { command: "reopen", description: "Reopen store immediately" },
    ];

    const commandsResponse = await axios.post(`${apiUrl}/setMyCommands`, {
      commands: commands,
    });

    if (!commandsResponse.data.ok) {
      throw new Error(
        `Failed to set commands: ${commandsResponse.data.description}`
      );
    }

    console.log("✅ Bot commands set successfully");

    // Get webhook info to verify
    const infoResponse = await axios.get(`${apiUrl}/getWebhookInfo`);
    const webhookInfo = infoResponse.data.result;

    console.log("📊 Webhook Information:");
    console.log(`   URL: ${webhookInfo.url}`);
    console.log(`   Has Certificate: ${webhookInfo.has_custom_certificate}`);
    console.log(`   Pending Updates: ${webhookInfo.pending_update_count}`);
    console.log(`   Max Connections: ${webhookInfo.max_connections}`);
    console.log(
      `   Allowed Updates: ${JSON.stringify(webhookInfo.allowed_updates)}`
    );

    // Get bot info
    const botInfoResponse = await axios.get(`${apiUrl}/getMe`);
    const botInfo = botInfoResponse.data.result;

    console.log("🤖 Bot Information:");
    console.log(`   Name: ${botInfo.first_name}`);
    console.log(`   Username: @${botInfo.username}`);
    console.log(`   ID: ${botInfo.id}`);
    console.log(`   Can Join Groups: ${botInfo.can_join_groups}`);
    console.log(`   Can Read Messages: ${botInfo.can_read_all_group_messages}`);

    console.log("\n🎉 Telegram bot setup completed successfully!");
    console.log(
      `\n📱 You can now chat with your bot at: https://t.me/${botInfo.username}`
    );
  } catch (error) {
    console.error("❌ Error setting up Telegram webhook:", error.message);

    if (error.response && error.response.data) {
      console.error(
        "   Response:",
        JSON.stringify(error.response.data, null, 2)
      );
    }

    process.exit(1);
  }
}

// Run setup if called directly
if (require.main === module) {
  setupTelegramWebhook();
}

module.exports = setupTelegramWebhook;
