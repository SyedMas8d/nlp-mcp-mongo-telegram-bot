const storeConfigService = require("../src/database/storeConfigService");

// Sample store configuration data
const sampleStoreConfig = {
  storeId: "7409",
  default: {
    openTime: "09:00",
    closeTime: "22:00",
    tempClosed: false,
    tempClosedTill: null,
    tempCloseMessage: "",
    enableCollectionOrders: true,
    enableDeliveryOrders: true,
    enableTableReservation: true,
    reservationSlots: [
      {
        start: "18:00",
        end: "19:00",
        maxReservations: 10,
      },
      {
        start: "19:30",
        end: "20:30",
        maxReservations: 8,
      },
    ],
    minimumOrderForDelivery: 15,
    storeName: "FVK Restaurant",
    storeLogo: "https://example.com/logo.png",
  },
  current: {
    openTime: "09:00",
    closeTime: "22:00",
    tempClosed: false,
    tempClosedTill: null,
    tempCloseMessage: "",
    enableCollectionOrders: true,
    enableDeliveryOrders: true,
    enableTableReservation: true,
    reservationSlots: [
      {
        start: "18:00",
        end: "19:00",
        maxReservations: 10,
      },
      {
        start: "19:30",
        end: "20:30",
        maxReservations: 8,
      },
    ],
    minimumOrderForDelivery: 15,
    storeName: "FVK Restaurant",
    storeLogo: "https://example.com/logo.png",
  },
};

async function seedDatabase() {
  try {
    console.log("🌱 Seeding database with sample data...");

    // Check if store already exists
    const existingStore = await storeConfigService.getStoreConfig("7409");

    if (existingStore) {
      console.log("ℹ️  Store 7409 already exists in database");
      console.log("📊 Current store data:");
      console.log(JSON.stringify(existingStore, null, 2));
      return;
    }

    // Create the store configuration
    await storeConfigService.createStoreConfig(sampleStoreConfig);

    console.log("✅ Sample store configuration created successfully!");
    console.log("📋 Store Details:");
    console.log(`   Store ID: ${sampleStoreConfig.storeId}`);
    console.log(`   Store Name: ${sampleStoreConfig.default.storeName}`);
    console.log(
      `   Hours: ${sampleStoreConfig.default.openTime} - ${sampleStoreConfig.default.closeTime}`
    );
    console.log(
      `   Min Delivery Order: $${sampleStoreConfig.default.minimumOrderForDelivery}`
    );

    console.log("\n🎉 Database seeded successfully!");
    console.log("\n💡 You can now test the bot with:");
    console.log('   • "What\'s the current status?"');
    console.log('   • "Close store for 30 minutes"');
    console.log('   • "Set minimum order to 20"');
    console.log('   • "Enable delivery service"');
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    process.exit(1);
  }
}

// Run seed if called directly
if (require.main === module) {
  require("dotenv").config();
  seedDatabase().then(() => {
    console.log("\n✨ Seeding completed!");
    process.exit(0);
  });
}

module.exports = seedDatabase;
