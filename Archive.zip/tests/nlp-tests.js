const nlpProcessor = require("../src/services/nlpProcessor");

// Test cases for NLP processing
const testCases = [
  {
    name: "Close Store - Minutes",
    input: "close the takeaway for 10 minutes",
    expectedIntent: "CLOSE_STORE",
    expectedParams: { durationMinutes: 10 },
  },
  {
    name: "Close Store - Hours",
    input: "shut down store for 2 hours",
    expectedIntent: "CLOSE_STORE",
    expectedParams: { durationMinutes: 120 },
  },
  {
    name: "Update Minimum Order",
    input: "change minimum order value to 25",
    expectedIntent: "UPDATE_MINIMUM_ORDER",
    expectedParams: { minimumAmount: 25 },
  },
  {
    name: "Update Store Hours",
    input: "set hours 09:00 22:00",
    expectedIntent: "UPDATE_STORE_HOURS",
    expectedParams: { openTime: "09:00", closeTime: "22:00" },
  },
  {
    name: "Enable Service",
    input: "enable delivery service",
    expectedIntent: "TOGGLE_SERVICE",
    expectedParams: { feature: "delivery", enabled: true },
  },
  {
    name: "Disable Service",
    input: "turn off collection",
    expectedIntent: "TOGGLE_SERVICE",
    expectedParams: { feature: "collection", enabled: false },
  },
  {
    name: "Get Status",
    input: "what is the current status?",
    expectedIntent: "GET_STATUS",
    expectedParams: {},
  },
  {
    name: "Reopen Store",
    input: "reopen the store",
    expectedIntent: "REOPEN_STORE",
    expectedParams: {},
  },
  {
    name: "Revert to Default",
    input: "revert to default settings",
    expectedIntent: "REVERT_TO_DEFAULT",
    expectedParams: {},
  },
  {
    name: "Help",
    input: "help me",
    expectedIntent: "HELP",
    expectedParams: {},
  },
  {
    name: "Unknown Intent",
    input: "what is the weather today?",
    expectedIntent: "UNKNOWN",
    expectedParams: {},
  },
];

function runNLPTests() {
  console.log("🧪 Running NLP Processor Tests...\n");

  let passedTests = 0;
  let totalTests = testCases.length;

  testCases.forEach((testCase, index) => {
    console.log(`Test ${index + 1}: ${testCase.name}`);
    console.log(`Input: "${testCase.input}"`);

    const result = nlpProcessor.detectIntent(testCase.input);

    console.log(`Expected Intent: ${testCase.expectedIntent}`);
    console.log(`Actual Intent: ${result.intent}`);
    console.log(`Confidence: ${result.confidence}`);
    console.log(`Parameters:`, result.parameters);

    // Check if intent matches
    const intentMatches = result.intent === testCase.expectedIntent;

    // Check if key parameters match (basic check)
    let parametersMatch = true;
    for (const [key, expectedValue] of Object.entries(
      testCase.expectedParams
    )) {
      if (result.parameters[key] !== expectedValue) {
        parametersMatch = false;
        break;
      }
    }

    const testPassed =
      intentMatches &&
      (result.confidence > 0.5 || testCase.expectedIntent === "UNKNOWN");

    if (testPassed) {
      console.log("✅ PASSED");
      passedTests++;
    } else {
      console.log("❌ FAILED");
      if (!intentMatches) {
        console.log(
          `   Intent mismatch: expected ${testCase.expectedIntent}, got ${result.intent}`
        );
      }
      if (!parametersMatch) {
        console.log(`   Parameter mismatch`);
      }
      if (result.confidence <= 0.5 && testCase.expectedIntent !== "UNKNOWN") {
        console.log(`   Low confidence: ${result.confidence}`);
      }
    }

    console.log("---\n");
  });

  console.log(`📊 Test Results: ${passedTests}/${totalTests} tests passed`);

  if (passedTests === totalTests) {
    console.log("🎉 All tests passed!");
  } else {
    console.log(`⚠️  ${totalTests - passedTests} tests failed`);
  }

  return passedTests === totalTests;
}

// Test specific NLP utilities
function runUtilityTests() {
  console.log("\n🔧 Testing NLP Utilities...\n");

  // Test duration parsing
  console.log("Duration Parsing Tests:");
  const durationTests = [
    { input: "10 minutes", expected: 10 },
    { input: "2 hours", expected: 120 },
    { input: "30 mins", expected: 30 },
    { input: "1.5 hours", expected: 90 },
    { input: "no duration", expected: null },
  ];

  durationTests.forEach((test) => {
    const result = nlpProcessor.parseDuration(test.input);
    const passed = result === test.expected;
    console.log(
      `  "${test.input}" → ${result} (expected: ${test.expected}) ${
        passed ? "✅" : "❌"
      }`
    );
  });

  // Test time extraction
  console.log("\nTime Extraction Tests:");
  const timeTests = [
    { input: "open at 09:00", expected: ["09:00"] },
    { input: "hours 09:00 to 22:00", expected: ["09:00", "22:00"] },
    { input: "set time 8:30", expected: ["08:30"] },
    { input: "no time here", expected: [] },
  ];

  timeTests.forEach((test) => {
    const result = nlpProcessor.extractTimes(test.input);
    const passed = JSON.stringify(result) === JSON.stringify(test.expected);
    console.log(
      `  "${test.input}" → ${JSON.stringify(
        result
      )} (expected: ${JSON.stringify(test.expected)}) ${passed ? "✅" : "❌"}`
    );
  });

  // Test service feature extraction
  console.log("\nService Feature Extraction Tests:");
  const serviceTests = [
    { input: "enable delivery", expected: "delivery" },
    { input: "turn off collection", expected: "collection" },
    { input: "disable takeaway", expected: "collection" },
    { input: "activate reservations", expected: "reservation" },
    { input: "no service here", expected: null },
  ];

  serviceTests.forEach((test) => {
    const result = nlpProcessor.extractServiceFeature(test.input);
    const passed = result === test.expected;
    console.log(
      `  "${test.input}" → ${result} (expected: ${test.expected}) ${
        passed ? "✅" : "❌"
      }`
    );
  });
}

// Run tests if called directly
if (require.main === module) {
  const allTestsPassed = runNLPTests();
  runUtilityTests();

  if (allTestsPassed) {
    console.log("\n🎊 All NLP tests completed successfully!");
    process.exit(0);
  } else {
    console.log("\n💥 Some tests failed. Please review the NLP processor.");
    process.exit(1);
  }
}

module.exports = { runNLPTests, runUtilityTests };
